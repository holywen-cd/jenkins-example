Nexus IQ Server is the policy engine that powers Nexus Firewall, Lifecycle, and Auditor.
With IQ Server, you can:

 * Share component intelligence with your teams so they make better decisions and build better software.
 * Implement a fully-customizeable policy engine letting you define which components are acceptable and which are not.
 * Provide a full suite of supported REST APIs that provide access to core features for custom implementations.
 * Our documentation is written to match the latest available release of the IQ Server and any associated integrations.

